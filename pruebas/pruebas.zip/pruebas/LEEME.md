# Pruebas (Node, sin Google)
Simulan hojas con datos reales del 22-oct-2026 (datos/parr_data.json) y cargan los .gs de ../apps-script.
Correr desde esta carpeta:  node t8.js  (categorias)  t9.js (parrillas, Estado Killers, precio manual, onEdit)
t10.js (archivo que se manda)  t11.js (solicitud / reconsiderar / elegir KAM)  t14.js (formato)  t15.js (cuenta regresiva)
Cada una termina con "N OK M FALLA". Esperado: M = 0. No prueban Google en vivo.
