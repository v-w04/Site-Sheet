// Popup: una tarjeta por tarea (indicador, resultado y hora). Se refresca solo mientras esta abierto.
const $ = id => document.getElementById(id);

function hace(ms) {
  const d = Date.now() - ms;
  if (d < 45000) return 'ahora';
  if (d < 3600000) return 'hace ' + Math.max(1, Math.round(d / 60000)) + ' min';
  const f = new Date(ms), hoy = new Date();
  const hh = f.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
  return f.toDateString() === hoy.toDateString() ? hh : f.toLocaleDateString('es-MX', { day: '2-digit', month: '2-digit' }) + ' ' + hh;
}

function tarjeta(id, titulo, est, vacio) {
  const el = $(id); if (!el) return;
  el.textContent = '';
  const p = document.createElement('i'); p.className = 'punto';
  const t = document.createElement('span'); t.className = 'tit'; t.textContent = titulo;
  const h = document.createElement('span'); h.className = 'hora'; h.textContent = est ? hace(est.hora) : '';
  const x = document.createElement('span'); x.className = 'txt'; x.textContent = est ? est.texto : vacio;
  el.append(p, t, h, x);
  el.className = 'fila' + (est ? (est.enCurso ? ' curso' : est.ok ? ' ok' : ' mal') : '');
}

async function pintar() {
  const g = await chrome.storage.local.get(['estado', 'estadoOdoo', 'estadoCancel', 'estadoSC', 'estadoWM', 'estadoRQ', 'estadoGA', 'gaActivo', 'gaModo', 'alertasSheet']);
  const al = $('al');
  if (al) {
    const x = g.alertasSheet, vivo = x && Array.isArray(x.lista) && x.lista.length && (Date.now() - x.hora) < 45 * 60000;
    al.textContent = '';
    if (vivo) {
      const t = document.createElement('b'); t.textContent = 'AVISO del Sheet (' + hace(x.hora) + ')'; al.append(t);
      x.lista.forEach(l => { const d = document.createElement('div'); d.textContent = l; al.append(d); });
    }
    al.style.display = vivo ? 'block' : 'none';
  }
  tarjeta('e', 'Cookie del site', g.estado, 'Sin envios todavia');
  tarjeta('od', 'Odoo', g.estadoOdoo, 'Sin envios todavia');
  tarjeta('ca', 'Cancelar en el site', g.estadoCancel, 'Sin revisar todavia');
  tarjeta('sc', 'Seller Center', g.estadoSC, 'Sin leer todavia');
  tarjeta('wm', 'Cancelar en Walmart (precio erroneo)', g.estadoWM, 'Sin revisar todavia');
  tarjeta('rq', 'Rastreo de guias (BigSmart / FedEx)', g.estadoRQ, 'Sin consultar todavia');
  tarjeta('gu', 'Guias ' + (g.gaActivo ? (g.gaModo === 'real' ? '(AUTOMATICAS: compra)' : '(automaticas: solo prueba)') : '(apagadas)'), g.estadoGA, 'Sin probar todavia');
}

// Los botones solo avisan al servicio y el popup se actualiza mirando lo que este va guardando (no esperan a que termine).
function pedir(tipo, id, titulo, texto, clave) {
  tarjeta(id, titulo, { texto, hora: Date.now(), enCurso: true });
  const falla = txt => chrome.storage.local.set({ [clave]: { ok: false, texto: txt, hora: Date.now() } });
  try {
    chrome.runtime.sendMessage({ tipo }).then(r => {
      if (r === undefined) falla('El servicio de la extension no respondio: recargala en chrome://extensions (Recargar)');
    }).catch(e => falla('No pude hablar con el servicio de la extension: ' + (e && e.message ? e.message : e)));
  } catch (e) { falla('No pude hablar con el servicio de la extension: ' + (e && e.message ? e.message : e)); }
  setTimeout(pintar, 800);
}
$('b').onclick = () => pedir('enviar', 'e', 'Cookie del site', 'Enviando...', 'estado');
$('c').onclick = () => pedir('cancelar', 'ca', 'Cancelar en el site', 'Revisando pendientes...', 'estadoCancel');
$('s').onclick = () => pedir('seller', 'sc', 'Seller Center', 'Leyendo Seller Center (abre una pestaña en segundo plano un momento)...', 'estadoSC');
$('g').onclick = () => pedir('guias', 'gu', 'Guias', 'Probando (abre la pagina de Guias en segundo plano; no compra nada)...', 'estadoGA');
// Comprar de verdad: dos pulsaciones (la segunda dentro de 6 s). Usa EXACTAMENTE los mismos candados que la corrida de cada hora.
let grReloj = null;
$('gr').onclick = () => {
  const b = $('gr');
  if (!grReloj) {
    b.textContent = '¿Seguro? Pulsa otra vez para COMPRAR';
    grReloj = setTimeout(() => { grReloj = null; b.textContent = 'Comprar guías AHORA (REAL)'; }, 6000);
    return;
  }
  clearTimeout(grReloj); grReloj = null; b.textContent = 'Comprar guías AHORA (REAL)';
  pedir('guias_real', 'gu', 'Guias', 'COMPRANDO guias de los pedidos que pasan los candados (abre la pagina de Guias en segundo plano)...', 'estadoGA');
};
$('o').onclick = () => chrome.runtime.openOptionsPage();
pintar();
setInterval(pintar, 1500);
